import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:note_app/colors.dart';
import 'package:note_app/note.dart';
import 'package:note_app/edit.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> filteredNotes = [];
  List<Note> deletedNotes = [];
  bool sorted = false;

  @override
  void initState() {
    super.initState();
    filteredNotes = sampleNotes;
  }

  Color getRandomColor() {
    Random random = Random();
    return backgroundColors[random.nextInt(backgroundColors.length)];
  }

  void onSearchTextChanged(String searchText) {
    setState(() {
      filteredNotes = sampleNotes
          .where((note) =>
              note.content.toLowerCase().contains(searchText.toLowerCase()) ||
              note.title.toLowerCase().contains(searchText.toLowerCase()))
          .toList();
    });
  }

  Future<void> restoreNoteAndNavigate(Note note) async {
    setState(() {
      note.isDeleted = false;
      deletedNotes.remove(note); // Remove the restored note from the deletedNotes list
      if (!filteredNotes.contains(note)) {
        filteredNotes.add(note);
        filteredNotes.sort((a, b) => a.title.compareTo(b.title));
      }
    });
    Navigator.pop(context); // Return to the notes screen
  }

  void deleteNote(int index) {
    setState(() {
      filteredNotes[index].isDeleted = true;
      deletedNotes.add(filteredNotes[index]); // Add the deleted note to the deletedNotes list
      filteredNotes.removeAt(index); // Remove the deleted note from the filteredNotes list
    });
  }

  Future<bool?> confirmDialog(BuildContext context) async {
    return showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Delete'),
          content: const Text('Are you sure you want to delete this note?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false); // Dismiss the dialog
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(true); // Dismiss the dialog and return true
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(156, 175, 170, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(156, 175, 170, 1.0),
        title: const Text(
          'NOTES',
          style: TextStyle(
            fontSize: 24,
            color: Color.fromARGB(255, 71, 53, 53),
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String choice) {
              if (choice == 'edit') {
                // Handle edit option
              } else if (choice == 'sortAZ') {
                setState(() {
                  filteredNotes.sort((a, b) => a.title.compareTo(b.title));
                });
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                const PopupMenuItem<String>(
                  value: 'sortAZ',
                  child: Text('Sort A-Z'),
                ),
              ];
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Column(
          children: [
            Container(
              height: 50,
              color: const Color.fromRGBO(156, 175, 170, 1.0),
              child: Center(
                child: Text(
                  'All Notes',
                  style: TextStyle(
                    color: Color.fromARGB(255, 71, 53, 53),
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: const Color.fromRGBO(141, 161, 155, 1),
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    ListTile(
                      title: const Text('Recycle Bin'),
                      onTap: () async {
                        final restoredNote = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DeletedNotesScreen(deletedNotes: deletedNotes),
                          ),
                        );

                        if (restoredNote != null) {
                          setState(() {
                            // Restore the note
                            restoreNoteAndNavigate(restoredNote);
                          });
                        }
                      },
                    ),
                    ListTile(
                      title: const Text('Folders'),
                      onTap: () {
                        // Handle new folder option
                        Navigator.pop(context); // Close the drawer
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(16, 40, 16, 0),
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            TextField(
              onChanged: onSearchTextChanged,
              style: const TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 82, 72, 72),
                fontWeight: FontWeight.bold,
              ),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                hintText: "Search notes...",
                hintStyle: const TextStyle(
                  color: Color.fromRGBO(75, 75, 75, 1),
                  fontWeight: FontWeight.w700,
                ),
                prefixIcon: const Icon(
                  Icons.search,
                  color: Color.fromRGBO(75, 75, 75, 1),
                ),
                fillColor: const Color.fromRGBO(214, 218, 200, 1.0),
                filled: true,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Colors.transparent),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Colors.transparent),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10.0,
                  mainAxisSpacing: 10.0,
                ),
                itemCount: filteredNotes.length,
                itemBuilder: (context, index) {
                  if (filteredNotes[index].isDeleted) {
                    return Container(); // Return an empty container for deleted notes
                  }

                  return GestureDetector(
                    onTap: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              EditScreen(note: filteredNotes[index]),
                        ),
                      );
                      if (result != null) {
                        setState(() {
                          int originalIndex =
                              sampleNotes.indexOf(filteredNotes[index]);

                          sampleNotes[originalIndex] = Note(
                            id: sampleNotes[originalIndex].id,
                            title: result[0],
                            content:                            result[1],
                            modifiedTime: DateTime.now(),
                          );

                          filteredNotes[index] = Note(
                            id: filteredNotes[index].id,
                            title: result[0],
                            content: result[1],
                            modifiedTime: DateTime.now(),
                          );
                        });
                      }
                    },
                    child: Card(
                      color: getRandomColor(),
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Stack(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  '${filteredNotes[index].title}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  '${filteredNotes[index].content}',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                  left: 8.0,
                                  bottom: 8.0,
                                  right: 8.0,
                                ),
                                child: Text(
                                  'Edited: ${DateFormat('EEE MMM d, yyyy h:mm a').format(filteredNotes[index].modifiedTime)}',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontStyle: FontStyle.italic,
                                    color: Colors.grey.shade800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: IconButton(
                              onPressed: () async {
                                final result = await confirmDialog(context);
                                if (result != null && result) {
                                  deleteNote(index);
                                }
                              },
                              icon: Icon(Icons.delete),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => const EditScreen(),
            ),
          );

          if (result != null) {
            setState(() {
              sampleNotes.add(Note(
                id: sampleNotes.length,
                title: result[0],
                content: result[1],
                modifiedTime: DateTime.now(),
              ));
              filteredNotes = sampleNotes;
            });
          }
        },
        elevation: 10,
        backgroundColor: const Color.fromRGBO(214, 218, 200, 1.0),
        child: const Icon(
          Icons.add,
          size: 38,
        ),
      ),
    );
  }
}

class DeletedNotesScreen extends StatefulWidget {
  final List<Note> deletedNotes;

  DeletedNotesScreen({required this.deletedNotes});

  @override
  _DeletedNotesScreenState createState() => _DeletedNotesScreenState();
}

class _DeletedNotesScreenState extends State<DeletedNotesScreen> {
  void _restoreNoteAndNavigate(Note note) {
    setState(() {
      widget.deletedNotes.remove(note); // Remove the restored note from the deletedNotes list
    });

    // Return to the main screen and pass the restored note back
    Navigator.pop(context, note);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recycle bin'),
      ),
      body: ListView.builder(
        itemCount: widget.deletedNotes.length,
        itemBuilder: (context, index) {
          final note = widget.deletedNotes[index];
          return ListTile(
            title: Text(note.title),
            subtitle: Text('Deleted: ${DateFormat('EEE MMM d, yyyy h:mm a').format(note.modifiedTime)}'),
            trailing: ElevatedButton(
              onPressed: () {
                _restoreNoteAndNavigate(note);
              },
              child: const Text('Restore'),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Do nothing if no note is selected
        },
        child: const Icon(Icons.restore),
      ),
    );
  }
}

