import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:note_app/note.dart';

class DeletedNotesScreen extends StatefulWidget {
  final List<Note> deletedNotes;
  final List<Note> notes; // List of all notes in the app

  DeletedNotesScreen({required this.deletedNotes, required this.notes});

  @override
  _DeletedNotesScreenState createState() => _DeletedNotesScreenState();
}

class _DeletedNotesScreenState extends State<DeletedNotesScreen> {
  Future<void> _showRestoreConfirmationDialog(Note note) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Restore Note'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                Text('Do you want to restore or delete this note?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                _restoreNote(note); // Call the restore function
              },
              child: const Text('Restore'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                _deletePermanently(note); // Call the delete permanently function
              },
              child: const Text('Delete Permanently'),
            ),
          ],
        );
      },
    );
  }

  void _restoreNote(Note note) {
    setState(() {
      note.isDeleted = false;
      // Remove the note from the deleted notes list
      widget.deletedNotes.remove(note);
      // Add the note to the main list if it's not already present
      if (!widget.notes.contains(note)) {
        widget.notes.add(note);
      }
    });

    // Return to the main screen
    Navigator.popUntil(context, ModalRoute.withName(Navigator.defaultRouteName));
  }

  void _deletePermanently(Note note) {
    setState(() {
      // Permanently delete the note
      widget.deletedNotes.remove(note);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recycle bin'),
      ),
      body: ListView.builder(
        itemCount: widget.deletedNotes.length,
        itemBuilder: (context, index) {
          final note = widget.deletedNotes[index];
          return ListTile(
            title: Text(note.title),
            subtitle: Text('Deleted: ${DateFormat('EEE MMM d, yyyy h:mm a').format(note.modifiedTime)}'),
            trailing: ElevatedButton(
              onPressed: () {
                _showRestoreConfirmationDialog(note);
              },
              child: const Text('Restore'),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Do nothing if no note is selected
        },
        child: const Icon(Icons.restore),
      ),
    );
  }
}
