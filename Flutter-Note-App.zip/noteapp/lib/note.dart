// note.dart
class Note {
  final int id;
  final String title;
  final String content;
  final DateTime modifiedTime;
  bool isDeleted;

  Note({
    required this.id,
    required this.title,
    required this.content,
    required this.modifiedTime,
    this.isDeleted = false, // Default value is false
  });
}




List<Note> sampleNotes = [
  Note(
    id: 0,
    title: 'Welcome to our NoteApp',
    content:
        'This NoteApp is made by Melanie and Ira',
    modifiedTime: DateTime(2024,03,23,33,49),
  ),

];